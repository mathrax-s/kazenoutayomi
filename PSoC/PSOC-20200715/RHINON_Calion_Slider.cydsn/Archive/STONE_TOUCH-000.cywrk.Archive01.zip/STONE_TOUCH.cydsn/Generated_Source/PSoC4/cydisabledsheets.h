#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Digital__DISABLED 1u
#define ADC__DISABLED 1u
#define DAC__DISABLED 1u
#define LCD__DISABLED 1u
#define System__DISABLED 1u
#define My_Design__DISABLED 1u

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
