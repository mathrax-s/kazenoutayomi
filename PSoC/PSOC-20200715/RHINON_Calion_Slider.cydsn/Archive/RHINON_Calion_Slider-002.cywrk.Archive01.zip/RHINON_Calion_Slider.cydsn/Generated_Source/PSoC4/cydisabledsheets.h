#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Digital__DISABLED 1u /* Digital */
#define ADC__DISABLED 1u /* ADC */
#define DAC__DISABLED 1u /* DAC */
#define LCD__DISABLED 1u /* LCD */
#define System__DISABLED 1u /* System */
#define My_Design__DISABLED 1u /* My Design */

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
